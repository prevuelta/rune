
var callback = function() {

	// var tablet = new Tablet();

	var rune = new Rune({
		xUnits: 6,
		yUnits: 6,
		xRes: 40,
		yRes: 40,
		canvasId: 'rune-grid',
		padding: 30
	}, paper);

	rune.addLetter();

}

setupPage([
	{
		"view" : "grid",
		"model": {

		},
		
	}], callback
);
