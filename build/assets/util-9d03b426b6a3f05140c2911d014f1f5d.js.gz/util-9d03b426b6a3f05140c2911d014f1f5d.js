// Requires mustache-wax
Mustache.Formatters = {

};
